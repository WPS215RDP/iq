import base64

def gamesdrive_encrypt(url):
    encrypted_url = base64.b64encode(url.encode()).decode()
    gamesdrive_url = f"https://links.gamesdrive.net/#/link/{encrypted_url}.SWNlUXVlZW4"
    return gamesdrive_url
