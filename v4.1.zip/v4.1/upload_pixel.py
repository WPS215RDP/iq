import os
import subprocess
import re
import shutil

def upload_iso(iso_path):
    file_name = os.path.splitext(os.path.basename(iso_path))[0]

    try:
        iso_path_escaped = f'"{iso_path}"'

        command = f'curl -T {iso_path_escaped} https://pixeldrain.com/api/file/'
        output = os.popen(command).read()
        
        match = re.search(r'{"id":"(.*?)"', output)
        if match:
            file_id = match.group(1)
            print(f"Uploaded {file_name}.iso")
            return f"https://pixeldrain.com/u/{file_id}"
        else:
            print(f"Error: Upload of {file_name}.iso failed.")
            return None
    except Exception as e:
        print(f"Error uploading {file_name}.iso: {e}")
        return None

def upload_isos_pixel(folder_path, iso_name):

    if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
        print(f"Folder '{folder_path}' does not exist or is not a directory :(")
        return

    iso_path = os.path.join(folder_path, iso_name)
    if not os.path.exists(iso_path):
        print(f"ISO file '{iso_name}' does not exist in '{folder_path}' :(")
        return

    response = upload_iso(iso_path)
    print(response)
    if response:
        print(f"File Link: {response}")
        return response
    else:
        print(f"Failed to upload {iso_name}")
        return None