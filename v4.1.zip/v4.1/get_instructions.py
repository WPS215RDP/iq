from bs4 import BeautifulSoup
import os

def get_instructions(folder_path):
    print(f"Checking instructions in {folder_path}...")
    html_files = [file for file in os.listdir(folder_path) if file.endswith(".html")]

    if not html_files:
        print(f"No HTML files found in {folder_path}.")
        return

    for html_file in html_files:
        print(f"Found {html_file}:")
        with open(os.path.join(folder_path, html_file), "r", encoding="utf-8") as file:
            soup = BeautifulSoup(file, "html.parser")
            span_elements = soup.find_all("span", class_="nfo_text")
            #tenoke, razor, doge, darksiders, skidrow handle
            instructions = [span.text.strip() for span in span_elements if span.text.strip().startswith(('1.', '2.', '3.', '4.', '5.', '6.', '7.', '8.'))]
            if not instructions: #iknow handle
              instructions = [span.text.strip() for span in span_elements if span.text.strip().startswith(('1 ', '2 ', '3 ', '4 '))]
            if not instructions: #flt handle
              instructions = [span.text.strip() for span in span_elements if span.text.strip().startswith('* ') and not span.text.strip().startswith("* Greetings")]
            if not instructions: #rune handle
              instructions = [span.text.strip() for span in span_elements if span.text.strip().startswith(('- ', '- ', '- ', '- '))]
            
            keywords = ["Unrar", "install"] #misc
            if not instructions: #dinobytes, tinyiso
              instructions = [span.text.strip() for span in span_elements if any(keyword in span.text.strip() for keyword in keywords)]

            '''
            for instruction in instructions:
              print(instruction)
            print("\n")
            '''
            return instructions



if __name__ == "__main__":
    folder_name = r"D:\test\3"
    get_instructions(folder_name)
