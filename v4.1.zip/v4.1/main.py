import time
import subprocess
import upload_torrent
import move_iso
import shutil
import os
import sys
from get_instructions import get_instructions
from get_original_link import get_original_link
from upload_gofile import upload_isos_gofile
from create_torrent import create_torrent_for_iso
from upload_torrent import upload_torrents
from upload_pixel import upload_isos_pixel
from encryption import gamesdrive_encrypt
from discord_webhook import (post_to_discord, post_cover_image_to_discord)
from variables import TORRENT_FILE_SAVED_AT, RLS_LOCK_FILE, PORTABLE_LOCK_FILE

def release_lock(lock_file):
    if os.path.exists(lock_file):
        os.remove(lock_file)

if __name__ == "__main__":

    if len(sys.argv) < 2:
        print("Usage: python main.py <folder_path>")
        sys.exit(1)

    folder_name = sys.argv[1]

    print(folder_name)
    for file_name in os.listdir(folder_name):
        if file_name.endswith(".iso"):
            full_iso_path = os.path.join(folder_name, file_name)

            iso_name = file_name
            print(f"ISO name: {iso_name}")
            
            pixel_url = upload_isos_pixel(folder_name, iso_name)
            print(f"File Link: {pixel_url}")

            if (pixel_url != None):
                gamesdrive_pixel_url = gamesdrive_encrypt(pixel_url)  
            else:
                gamesdrive_pixel_url = "failed_to_upload"  
            print(f"Encrypted URL: {gamesdrive_pixel_url}")

            gofile_url = upload_isos_gofile(full_iso_path, False)
            print(f"File Link: {gofile_url}")

            if (gofile_url != None):
                gamesdrive_gofile_url = gamesdrive_encrypt(gofile_url)  
            else:
                gamesdrive_gofile_url = "failed_to_upload"
            print(f"Encrypted URL: {gamesdrive_gofile_url}")
            
            move_iso.move_iso(full_iso_path)
            
            create_torrent_for_iso(iso_name)
            
            torrent_url = upload_torrent.upload_torrents(TORRENT_FILE_SAVED_AT)
            print(torrent_url)

            if (torrent_url != None):
                gamesdrive_torrent_url = gamesdrive_encrypt(torrent_url) 
            else:
                gamesdrive_torrent_url = "failed_to_upload"  
            print(f"Encrypted URL: {gamesdrive_torrent_url}")
                        
            page_link = get_original_link(folder_name)

            instructions = get_instructions(folder_name)

            cover_link = post_cover_image_to_discord(page_link)
            post_to_discord(gamesdrive_gofile_url, gamesdrive_torrent_url, page_link, cover_link, instructions, folder_name)

            shutil.rmtree(folder_name)

            release_lock(PORTABLE_LOCK_FILE)
            print("Portable lock reset")
            release_lock(RLS_LOCK_FILE)
            print("Release lock reset ")
