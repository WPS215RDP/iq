import os
import subprocess

from variables import SCRIPT_FOLDER, PORTABLES_TO_BE_PACKED, EXTRACTED_ISO
  
def installer_arc_unpack(folder_name):

  OUTPUT_FOLDER = os.path.join(PORTABLES_TO_BE_PACKED, folder_name)
  unpack_bat_path = os.path.join(SCRIPT_FOLDER, '_Custom')
  archive_path = os.path.join(SCRIPT_FOLDER, "archive.py")

  print(OUTPUT_FOLDER)
  print(unpack_bat_path)

  subprocess.Popen(["start", "cmd", "/k", "Unpack_Ins_Arc.bat", fr"{EXTRACTED_ISO}\{folder_name}", OUTPUT_FOLDER, archive_path], shell=True, cwd=unpack_bat_path, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)