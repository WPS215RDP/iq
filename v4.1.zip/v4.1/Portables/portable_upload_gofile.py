import subprocess
import sys
import json

def upload_isos_gofile(file_path):

    server_process = subprocess.Popen(["curl", "-s", "https://api.gofile.io/getServer"], stdout=subprocess.PIPE)
    server_response, _ = server_process.communicate()
    server_data = json.loads(server_response.decode())
    server = server_data["data"]["server"]

    upload_process = subprocess.Popen(["curl", "-F", f"file=@{file_path}", f"https://{server}.gofile.io/uploadFile"], stdout=subprocess.PIPE)
    upload_response, _ = upload_process.communicate()
    upload_data = json.loads(upload_response.decode())
    link = upload_data["data"]["downloadPage"]

    return link

if len(sys.argv) < 2:
    
    sys.exit(1)

