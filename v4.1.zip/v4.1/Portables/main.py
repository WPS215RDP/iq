import os
import sys
import subprocess
from variables import EXTRACTED_ISO
from rune_unpack import rune_unpack
from arc_unpack import arc_unpack
from installer_arc_unpack import installer_arc_unpack
from tenoke_unpack import tenoke_unpack

def portable_main(folder_path):
    folder_name = os.path.basename(folder_path)
    iso_file = None
    for file_name in os.listdir(folder_path):
        if file_name.endswith(".iso"):
            iso_file = os.path.join(folder_path, file_name)
            break

    if iso_file is None:
        print("No .iso file found in the folder.")
        return

    print(folder_name)
    subprocess.run(["C:\\Program Files\\7-zip\\7z.exe", "x", iso_file, fr"-o{EXTRACTED_ISO}\{folder_name}"], check=True)
    print("ISO extracted successfully.")

    if folder_name.endswith("-TENOKE"):
        tenoke_unpack(folder_name)
    if folder_name.endswith("-RUNE"):
        rune_unpack(folder_name)
    elif folder_name.endswith("-DARKSiDERS") or folder_name.endswith("-SKIDROW") or folder_name.endswith("-TiNYiSO"):
        arc_unpack(folder_name)
    elif folder_name.endswith("-FLT") or folder_name.endswith("-DOGE"):
        installer_arc_unpack(folder_name)
    else:
        print("hi")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python main.py <folder_path>")
        sys.exit(1)

    folder_path = sys.argv[1]
    portable_main(folder_path)
