import os
import subprocess
import time
import pyautogui
import psutil
import shutil

from variables import (SCRIPT_FOLDER, PORTABLES_TO_BE_PACKED, EXTRACTED_ISO, 
                       TENOKE_OK_BTN_X, TENOKE_OK_BTN_Y, 
                       TENOKE_INSTALL_BTN_X, TENOKE_INSTALL_BTN_Y, 
                       TENOKE_UNINSTALL_BTN_X, TENOKE_UNINSTALL_BTN_Y, 
                       TENOKE_SHORTCUT_BTN_X, TENOKE_SHORTCUT_BTN_Y, 
                       TENOKE_FIRST_CLICK_X, TENOKE_FIRST_CLICK_Y,
                       TENOKE_INSTALL_TO_FIELD_X, TENOKE_INSTALL_TO_FIELD_Y)

def tenoke_unpack(folder_name):

    OUTPUT_FOLDER = os.path.join(PORTABLES_TO_BE_PACKED, folder_name)
    setup_path = fr"{EXTRACTED_ISO}\{folder_name}\SETUP.exe"
    set_install_path = fr"{PORTABLES_TO_BE_PACKED}\{folder_name}"
    archive_path = os.path.join(SCRIPT_FOLDER, "archive.py")

    print(OUTPUT_FOLDER)
    print(archive_path)

    subprocess.Popen([setup_path])

    time.sleep(1)

    tenoke_started = False
    for proc in psutil.process_iter(['name']):
        if proc.info['name'] == "SETUP.exe":
            tenoke_started = True
            break
    if tenoke_started:
      pyautogui.click(TENOKE_FIRST_CLICK_X, TENOKE_FIRST_CLICK_Y)
      time.sleep(1)

      pyautogui.click(TENOKE_INSTALL_TO_FIELD_X, TENOKE_INSTALL_TO_FIELD_Y)
      pyautogui.press('tab')
      pyautogui.press('delete')
      pyautogui.typewrite(set_install_path)

      pyautogui.click(TENOKE_SHORTCUT_BTN_X, TENOKE_SHORTCUT_BTN_Y)
      pyautogui.click(TENOKE_UNINSTALL_BTN_X, TENOKE_UNINSTALL_BTN_Y)
      pyautogui.click(TENOKE_INSTALL_BTN_X, TENOKE_INSTALL_BTN_Y)   

    while tenoke_started:
        pyautogui.click(TENOKE_OK_BTN_X, TENOKE_OK_BTN_Y)
        
        time.sleep(5) 

        for proc in psutil.process_iter(['name']):
            if proc.info['name'] == "SETUP.exe":
                tenoke_started = True
                break
            else:
                tenoke_started = False
    
    shutil.rmtree(fr"{EXTRACTED_ISO}\{folder_name}")
    subprocess.Popen(["start", "cmd", "/k", "python", archive_path, OUTPUT_FOLDER], shell = True)

