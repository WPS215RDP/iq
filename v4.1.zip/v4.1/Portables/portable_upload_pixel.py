import os
import subprocess
import re
import shutil

def upload_iso(iso_path):
    file_name = os.path.splitext(os.path.basename(iso_path))[0]

    try:
        iso_path_escaped = f'"{iso_path}"'

        command = f'curl --globoff -T {iso_path_escaped} https://pixeldrain.com/api/file/'
        output = os.popen(command).read()
        
        match = re.search(r'{"id":"(.*?)"', output)
        if match:
            file_id = match.group(1)
            print(f"Uploaded {file_name}.iso")
            return f"https://pixeldrain.com/u/{file_id}"
        else:
            print(f"Error: Upload of {file_name}.iso failed.")
            return None
    except Exception as e:
        print(f"Error uploading {file_name}.iso: {e}")
        return None

def upload_isos_pixel(iso_path):

    response = upload_iso(iso_path)
    print(response)
    if response:
        print(f"File Link: {response}")
        return response
    else:
        print(f"Failed to upload")
        return None