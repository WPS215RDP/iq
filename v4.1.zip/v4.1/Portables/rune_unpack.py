import os
import subprocess

from variables import SCRIPT_FOLDER, PORTABLES_TO_BE_PACKED, EXTRACTED_ISO

def rune_unpack(folder_name):
    config_o_path = os.path.join(SCRIPT_FOLDER, '_Custom', 'Unpacker', 'config_o.ini')
    with open(config_o_path, 'r') as f:
        config_o_contents = f.read()
    
    OUTPUT_FOLDER = os.path.join(PORTABLES_TO_BE_PACKED, folder_name)

    bin_path = os.path.join(EXTRACTED_ISO + "\\" + folder_name + '\\', 'setup-1.bin')

    config_contents = config_o_contents.replace('.\\setup-1.bin', bin_path).replace('.\\CODEX-DATA', OUTPUT_FOLDER)
    
    config_path = os.path.join(SCRIPT_FOLDER, '_Custom', 'Unpacker', 'config.ini')

    print("CONFIG CONTENTS:")
    print(config_contents)
    print("CONFIG PATH:")
    print(config_path)
    
    with open(config_path, 'w') as f:
        f.write(config_contents)
    print("CONFIG.INI CREATED")
    
    unpack_bat_path = os.path.join(SCRIPT_FOLDER, '_Custom', 'Unpacker')
    archive_path = os.path.join(SCRIPT_FOLDER, "archive.py")

    subprocess.Popen(["start", "cmd", "/k", "Unpack_RUNE.bat", fr"{EXTRACTED_ISO}\{folder_name}", OUTPUT_FOLDER, archive_path], shell=True, cwd=unpack_bat_path, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    

