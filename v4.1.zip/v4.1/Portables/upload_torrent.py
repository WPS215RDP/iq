import os
import subprocess
import re
import shutil
from variables import TORRENT_FILE_SAVED_AT

def upload_torrents(torrent_folder):
    if not os.path.exists(torrent_folder) or not os.path.isdir(torrent_folder):
        print(f"Torrent folder '{torrent_folder}' does not exist :(")
        return

    uploaded_folder = os.path.join(torrent_folder, "Uploaded_to_Pixel")
    if not os.path.exists(uploaded_folder):
        os.makedirs(uploaded_folder)

    for file_name in os.listdir(torrent_folder):
        if file_name.endswith('.torrent'):
            torrent_path = os.path.join(torrent_folder, file_name)
            print(torrent_path)
            response = upload_torrent(torrent_path)
            if response:
                print(f"Torrent uploaded: {file_name}")
                shutil.move(torrent_path, os.path.join(uploaded_folder, file_name))
                return response
            else:
                print(f"Failed to upload torrent: {file_name}")
                return None

def upload_torrent(torrent_path):
    try:
        command = ['curl', '--globoff', '-T', torrent_path, 'https://pixeldrain.com/api/file/']
        output = subprocess.check_output(command, text=True, stderr=subprocess.STDOUT)
        
        match = re.search(r'{"id":"(.*?)"', output)
        if match:
            file_id = match.group(1)
            return f"https://pixeldrain.com/u/{file_id}"
        else:
            print(f"Error: Upload of {torrent_path} failed.")
            return None
    except Exception as e:
        print(f"Error uploading {torrent_path}: {e}")
        return None

def main():
    torrent_folder = TORRENT_FILE_SAVED_AT
    upload_torrents(torrent_folder)

if __name__ == "__main__":
    main()
