import sys
import subprocess
import os
import shutil
from variables import SEEDING_FOLDER, TORRENT_FILE_SAVED_AT, ROOT_FOLDER_OF_MILKIE_ISOS, PORTABLE_LOCK_FILE, SCRIPT_FOLDER
from portable_upload_gofile import upload_isos_gofile
from portable_upload_pixel import upload_isos_pixel
from gamesdrive_encrypt import gamesdrive_encrypt
from create_torrent import create_torrent_for_iso
from upload_torrent import upload_torrents
from get_original_link import get_original_link
from discord_webhook import (post_to_discord, post_cover_image_to_discord)

def release_lock(lock_file):
    if os.path.exists(lock_file):
        os.remove(lock_file)
        
if __name__ == "__main__":
    
    if len(sys.argv) != 2:
        print("Usage: python archive.py OUTPUT_FOLDER")
        sys.exit(1)

    output_folder = sys.argv[1]

    folder_name = os.path.basename(output_folder)
    portable_folder_name = folder_name + ' [PORTABLE]'
    portable_folder_path = os.path.join(os.path.dirname(output_folder), portable_folder_name)
    #os.rename(output_folder, portable_folder_path)
    shutil.move(output_folder, portable_folder_path)

    zip_to_upload = f"{SEEDING_FOLDER}\\{portable_folder_name}.7z"
    subprocess.run(["C:\\Program Files\\7-zip\\7z.exe", "a", zip_to_upload, portable_folder_path], check = True)

    print(portable_folder_path)
    
    portable_pixel_url = None
    print(f"File Link: {portable_pixel_url}")
    if (portable_pixel_url != None):
        gamesdrive_pixel_url = gamesdrive_encrypt(portable_pixel_url)
    else:
        gamesdrive_pixel_url = "failed to upload"

    portable_gofile_url = upload_isos_gofile(zip_to_upload)
    print(f"File Link: {portable_gofile_url}")
    if (portable_gofile_url != None):
        gamesdrive_gofile_url = gamesdrive_encrypt(portable_gofile_url)
    else:
        gamesdrive_gofile_url = "failed to upload"

    create_torrent_for_iso(portable_folder_name)

    torrent_url = upload_torrents(TORRENT_FILE_SAVED_AT)
    print(torrent_url)
    if (torrent_url != None):
        gamesdrive_torrent_url = gamesdrive_encrypt(torrent_url)
    else:
        gamesdrive_torrent_url = "failed to upload"

    page_link = get_original_link(fr"{ROOT_FOLDER_OF_MILKIE_ISOS}\{folder_name}")
    
    instructions = ["1. Download the release", 
                    "2. Extract it using WinRAR/7-zip", 
                    "3. Install VC++/directx dependenices",
                    "4. Navigate to the .exe and play"]
    
    cover_link = post_cover_image_to_discord(page_link)
    post_to_discord(gamesdrive_pixel_url, portable_folder_name, gamesdrive_gofile_url, gamesdrive_torrent_url, page_link, cover_link, instructions, folder_name)

    os.remove(zip_to_upload)

    release_lock(PORTABLE_LOCK_FILE)
    print("Portable lock reset")

    
