ROOT_FOLDER_OF_MILKIE_ISOS = r"D:\test"

SCRIPT_FOLDER = r"D:\test\v4.1\Portables"

PORTABLES_TO_BE_PACKED = r"D:\test\idk"

EXTRACTED_ISO = r"D:\test\iso"

SEEDING_FOLDER = r"D:\test"

TRACKERS_LIST = ["udp://tracker.opentrackr.org:1337", 
                "udp://explodie.org:6969/announce", 
                "udp://tracker.torrent.eu.org:451/announce", 
                "http://open.acgnxtracker.com:80/announce", 
                "udp://oh.fuuuuuck.com:6969/announce", 
                "http://tracker.bt4g.com:2095/announce", 
                "udp://opentracker.io:6969/announce", 
                "https://tracker.tamersunion.org:443/announce", 
                "udp://ec2-18-191-163-220.us-east-2.compute.amazonaws.com:6969/announce", 
                "https://trackers.mlsub.net:443/announce", 
                "http://tracker.files.fm:6969/announce", 
                "https://tracker.loligirl.cn:443/announce", 
                "https://tracker.yemekyedim.com:443/announce", 
                "http://bt.okmp3.ru:2710/announce", 
                "udp://run.publictracker.xyz:6969/announce", 
                "udp://tracker.torrent.eu.org:451/announce"] 

TORRENT_FILE_SAVED_AT = r"D:\test\4"

DISCORD_WEBHOOK_URL = 'https://discord.com/api/webhooks/1234801565638983763/OCbhEOfNYkSZOQxYRjoH69EkgjD8k_XfUEaICm22M_uenHq7n_LZo4ixj9sfbaIQt0wC'

DISCORD_WEBHOOK_USERNAME = 'cr'

DISCORD_ROLE_ID = '1236587493663445092'

TENOKE_FIRST_CLICK_X = 960
TENOKE_FIRST_CLICK_Y = 435

TENOKE_INSTALL_BTN_X = 920
TENOKE_INSTALL_BTN_Y = 705

TENOKE_OK_BTN_X = 1065
TENOKE_OK_BTN_Y = 585

TENOKE_SHORTCUT_BTN_X = 605
TENOKE_SHORTCUT_BTN_Y = 675

TENOKE_UNINSTALL_BTN_X = 605
TENOKE_UNINSTALL_BTN_Y = 700

TENOKE_INSTALL_TO_FIELD_X = 980
TENOKE_INSTALL_TO_FIELD_Y = 610

PORTABLE_LOCK_FILE = r"D:\test\v4.1\Portables\portables_lock.lock"
