import requests
import os
from datetime import datetime
from scrape_gog_for_img import scrape_thumbnail_image
from variables import (DISCORD_WEBHOOK_URL, DISCORD_WEBHOOK_USERNAME, DISCORD_ROLE_ID)

def post_cover_image_to_discord(page_link):

    if page_link == None:
        cover_link = "https://i.imgur.com/GKVNjts.png"
    else:
        if page_link.startswith("gog.com"):
            cover_link = scrape_thumbnail_image(page_link)
        else:
            if page_link.endswith("/"):
                page_link = page_link[:-1]
            app_id = page_link.split("/")[-1]
            cover_link = f"https://cdn.akamai.steamstatic.com/steam/apps/{app_id}/header.jpg"
    return cover_link

def post_to_discord(pixel_link, portable_folder_name, gofile_link, torrent_link, page_link, cover_link, instructions, folder_name):

    if page_link == None:
        page_link = "<place_holder>"
    else:
        if page_link.startswith("gog.com"):
            page_link = page_link.replace("gog.com", "https://gog.com")
        elif page_link.startswith("store.steampowered.com"):
            page_link = page_link.replace("store.steampowered.com", "https://store.steampowered.com")
            
    folder_name = os.path.basename(folder_name)

    separator = "\n"
    instructions_formatted = separator.join(instructions)

    now = datetime.now()
    dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
    data = {
        "username" : DISCORD_WEBHOOK_USERNAME,
        "content": "<@&" + DISCORD_ROLE_ID + ">"
    }

    data["embeds"] = [
        {
            "type": "rich",
            "title": portable_folder_name,
            "description": "",
            "color": 0x00FFFF,
            "image": {
                "url": cover_link
            },
            "fields": [
                {
                    "name": "Steam/GOG Page",
                    "value": page_link
                },
                {
                    "name": 'Source/Credits',
                    "value": folder_name
                },
                {
                    "name": 'Pixeldrain Link',
                    "value": pixel_link
                },
                {
                    "name": 'Gofile Link',
                    "value": gofile_link
                },
                {
                    "name": 'Torrent Link',
                    "value": torrent_link
                },
                {
                    "name": 'Instructions',
                    "value": instructions_formatted
                }
                
            ],
            "footer": {
                "text": f'Uploaded at {dt_string}'
            }
        }
    ]

    response = requests.post(DISCORD_WEBHOOK_URL, json=data)
    return response
