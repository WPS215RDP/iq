import os
import subprocess
import shutil
from variables import (PORTABLES_TO_BE_PACKED, TRACKERS_LIST, SCRIPT_FOLDER, TORRENT_FILE_SAVED_AT)

def create_torrent_for_iso(portable_folder_name):

    parent_folder = PORTABLES_TO_BE_PACKED
    trackers = TRACKERS_LIST

    if not os.path.exists(parent_folder) or not os.path.isdir(parent_folder):
        print(f"Parent folder '{parent_folder}' does not exist :(")
        return

    iso_path = os.path.join(parent_folder, portable_folder_name)

    if not os.path.exists(iso_path):
        print(f"folder '{portable_folder_name}' does not exist in '{parent_folder}' :(")
        return

    try:
        command = ['py3createtorrent', iso_path]
        for tracker in trackers:
            command.extend(['-t', tracker])
        subprocess.run(command, check=True)
        print(f"Torrent file created for ISO '{portable_folder_name}'. :)")
    except subprocess.CalledProcessError as e:
        print(f"Error creating torrent for ISO : {e} :(")

    source_folder = SCRIPT_FOLDER
    destination_folder = TORRENT_FILE_SAVED_AT
    
    for file_name in os.listdir(source_folder):
        if file_name.endswith('.torrent'):
            source_path = os.path.join(source_folder, file_name)
            destination_path = os.path.join(destination_folder, file_name)
            try:
                shutil.move(source_path, destination_path)
                print(f"Moved '{file_name}' to '{destination_folder}'")
            except Exception as e:
                print(f"Error moving '{file_name}': {e}")
    

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python create_torrent.py [iso_name]")
        sys.exit(1)
    iso_name = sys.argv[1]
    create_torrent_for_iso(iso_name)