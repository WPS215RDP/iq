import os
import shutil
import subprocess
from variables import ROOT_FOLDER_OF_MILKIE_ISOS, SEEDING_FOLDER

def move_iso(full_iso_path):
    if os.path.exists(full_iso_path):
        shutil.move(full_iso_path, SEEDING_FOLDER)
        print(f"{full_iso_path} moved to {SEEDING_FOLDER}")
    else:
        print(f"ISO file '{full_iso_path}' does not exist in '{ROOT_FOLDER_OF_MILKIE_ISOS}' :(")

