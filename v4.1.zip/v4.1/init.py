import subprocess
import sys
import os
from variables import SCRIPT_FOLDER

if __name__ == "__main__":

    if len(sys.argv) != 5:
        print("Usage: python init.py arg1 arg2 arg3 arg4")
        sys.exit(1)

    folder_name = sys.argv[1].strip('"')
    root_folder = sys.argv[2].strip('"')
    folder_size = sys.argv[3].strip('"')
    torrent_hash = sys.argv[4].strip('"')

    folder_path = os.path.join(root_folder, folder_name)
    print(torrent_hash)

    if not folder_name.endswith(".iso") or folder_name.endswith("[PORTABLE]"):
        
        os.chdir(SCRIPT_FOLDER)

        del_torrent=subprocess.Popen(["start", "cmd", "/k", "qbt", "torrent", "delete", torrent_hash], shell=True)
        del_torrent.wait()
        subprocess.Popen(["start", "cmd", "/k", "python", "main.py", folder_path], shell=True)
        

            