import requests
import argparse
import json
import xml.etree.ElementTree as ET
import os

verbose = False
server = None

def getServer(verbose):
    url = "https://api.gofile.io/getServer"
    response = requests.get(url)

    if response.status_code == 200:
        data = json.loads(json.dumps(response.json()))
        if data['status'] == "ok":
            servername = data["data"]["server"]
            if verbose:
                print("JSON PARSEABLE")
            return servername
        if verbose:
            print("JSON isnt PARSEABLE")
        return 0
    else:
        if verbose:
            print("couldnt return server.")
        return 0

def upload_isos_gofile(filepath, verbose):
    if getServer(verbose) != 0:
        global server
        server = getServer(verbose)
        url = "https://" + getServer(verbose) + ".gofile.io/uploadFile"
        if verbose:
            print('uploading '+filepath)
        files = {'file': (os.path.basename(filepath), open(filepath, 'rb'))}
        if verbose:
            print('request at "'+url+'"')
        response = requests.post(url, files=files)
        if verbose:
            print('req made')
        if response.status_code == 200:
            data = response.json()
            download_url = data['data']['downloadPage']
            return download_url

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="hi ice :)")

    parser.add_argument("-u", "--upload", help="load from local path")

    args = parser.parse_args()

    link = upload_isos_gofile(args.upload,verbose)

    print(link)

