import pyautogui
import time

while True:
  time.sleep(2)
  pyautogui.click(100,100)
  print("clicked")