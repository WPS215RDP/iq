import sys
import subprocess
import os
from variables import RAR_FOLDER, PORTABLE_LOCK_FILE, SCRIPT_FOLDER
from portable_upload_gofile import upload_isos_gofile
from gamesdrive_encrypt import gamesdrive_encrypt

from discord_webhook import (post_to_discord, post_cover_image_to_discord)

def release_lock(lock_file):
    if os.path.exists(lock_file):
        os.remove(lock_file)
        
if __name__ == "__main__":
    
    if len(sys.argv) != 2:
        print("Usage: python archive.py OUTPUT_FOLDER")
        sys.exit(1)

    output_folder = sys.argv[1]

    os.chdir(SCRIPT_FOLDER)

    folder_name = os.path.basename(output_folder)
    portable_folder_name = folder_name + '.STEAMRiP.COM'
    portable_folder_path = os.path.join(os.path.dirname(output_folder), portable_folder_name)
    os.rename(output_folder, portable_folder_path)
    #shutil.move(output_folder, portable_folder_path)

    zip_to_upload = f"{RAR_FOLDER}\\{portable_folder_name}.rar"
    subprocess.run(["C:\\Program Files\\WinRAR\\Rar.exe", "a", zip_to_upload, portable_folder_path], check = True)

    print(portable_folder_path)

    portable_gofile_url = upload_isos_gofile(zip_to_upload)
    print(f"File Link: {portable_gofile_url}")
    if (portable_gofile_url == None):
        portable_gofile_url = None

    post_to_discord(portable_folder_name, portable_gofile_url, folder_name)

    os.remove(zip_to_upload)

    release_lock(PORTABLE_LOCK_FILE)
    print("Portable lock reset")

    
