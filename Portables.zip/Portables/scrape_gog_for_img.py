import requests
from bs4 import BeautifulSoup

def scrape_thumbnail_image(page_link):
    
  game_url = page_link.replace("gog.com", "https://embed.gog.com")

  response = requests.get(game_url)
    
  if response.status_code == 200:
      
      soup = BeautifulSoup(response.content, 'html.parser')
        
      img_tag = soup.find('img', {'class': 'productcard-thumbnails-slider__image'})
        
      if img_tag:
          cover_link = img_tag['src']
          return cover_link
      else:
          return None
  else:
      print("Failed to fetch the URL:", game_url)
      return None

