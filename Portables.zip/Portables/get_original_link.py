import os
import subprocess
import re

def get_original_link(folder_name):
    
    folder_path = os.path.join(os.getcwd(), folder_name)

    nfo_files = [f for f in os.listdir(folder_path) if f.lower().endswith('.nfo')]

    if not nfo_files:
        print("No .nfo file found in the specified folder.")
        return None

    nfo_file = nfo_files[0]

    command = f"infekt-cmd.exe -S -m \"{os.path.join(folder_path, nfo_file)}\""
    subprocess.run(command, shell=True)

    html_file = os.path.join(folder_path, nfo_file.replace(".nfo", ".html"))

    if not os.path.exists(html_file):
        print(f"HTML file '{html_file}' not found.")
        return None

    with open(html_file, "r") as f:
        html_content = f.read()

    urls = re.findall(r'(store\.steampowered\.com\app/\d+/|gog\.com/\S+)', html_content)

    if urls:
        original_link = urls[0]
        
        if original_link.endswith('"'):
            original_link = original_link[:-1]
        if original_link.endswith('</span>'):
            original_link = original_link[:-7]
        print(f"Original link found: {original_link}")
        return original_link
    else:
        print("No original link found.")
        return None

if __name__ == "__main__":
    folder_name = input("Enter the folder name containing the .nfo file: ")
    get_original_link(folder_name)
